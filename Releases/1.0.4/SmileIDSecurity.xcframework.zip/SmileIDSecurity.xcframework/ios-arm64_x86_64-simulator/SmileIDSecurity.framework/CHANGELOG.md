# Release Notes

## 0.0.0

### Added

* Initial release 🎉
