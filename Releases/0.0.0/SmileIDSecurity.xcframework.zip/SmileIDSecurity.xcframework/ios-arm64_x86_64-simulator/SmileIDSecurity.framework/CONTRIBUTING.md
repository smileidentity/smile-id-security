# Smile ID Secure iOS SDK

## Overview

This repo contains all the code required to run the Smile ID Secure iOS SDK. The project folder structure is described below.

- `Sources`- Contains all source code

## Requirements

- iOS 13 or higher
- Xcode 14 or higher

To generate the xcodeproj file, we use xcodegen. To install xcodegen run:
```shell
brew install xcodegen
```

Then, to generate the xcodeproj file run:

```shell
xcodegen
```
This needs to be run whenever there is a change in the file structure (eg. after a git pull and new files are being added to the project). 