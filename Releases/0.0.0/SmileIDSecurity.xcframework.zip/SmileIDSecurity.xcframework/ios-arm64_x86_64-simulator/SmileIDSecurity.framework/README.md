# Smile ID Secure iOS SDK

Please see [CHANGELOG.md](CHANGELOG.md) or 
[Releases](https://github.com/smileidentity/ios-secure/releases) for the most recent version and 
release notes

#### 0. Requirements

- iOS 13 and above
- Xcode 14 and above

## Contributing

Bug reports and Pull Requests are welcomed. Please see [CONTRIBUTING.md](CONTRIBUTING.md)
